<main id="site-content" class="flex-grow-1 <?php
if (!is_page_template('page-templates/template-full-width-page-without-header-title.php')) {
    echo 'nav-white-desktop';
} else {
    echo 'nav-black-desktop';
}
?>" role="main">
    <?php

    if (have_posts()) {

        if (!is_search()) {
            get_template_part('template-parts/featured-media');
        }

        while (have_posts()) {
            the_post();

            get_template_part('template-parts/content', get_post_type());
        }
    }

    ?>
</main><!-- #site-content -->