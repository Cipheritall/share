<?php
/**
 * The template for displaying single posts and pages.
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 * @since Toka 1.0
 */

get_header();

get_template_part('template-parts/layout-container');

get_footer();